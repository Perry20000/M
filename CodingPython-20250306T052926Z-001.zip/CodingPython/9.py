def outer():
    x = "outer"
    def inner():
        return x
    return inner()
print(outer())        