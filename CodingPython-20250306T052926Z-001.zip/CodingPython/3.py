from itertools import chain
list1 = [1, 2]
list2 = [3, 4]
result = list(chain(list1, list2))
print(result)