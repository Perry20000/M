marks = [10, 15, 20]
marks[1] = 12
print(marks)