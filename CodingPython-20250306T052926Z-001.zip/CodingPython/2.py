nums =[1, 2, 3, 4, 5]
squared = [x**2 for x in nums if x > 2]
print(squared)