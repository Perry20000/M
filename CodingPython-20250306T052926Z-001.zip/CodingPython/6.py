import random

# List of possible words (you can add more words to this list)
word_list = ["apple", "berry", "charm", "delta", "grape", "mango", "pearl", "stone", "table", "tiger"]

# Choose a random word from the list
target_word = random.choice(word_list)

# Function to provide feedback for a guess
def get_feedback(guess, target):
    feedback = []
    for i, letter in enumerate(guess):
        if letter == target[i]:
            feedback.append("🟩")  # Correct letter in the correct position
        elif letter in target:
            feedback.append("🟨")  # Correct letter in the wrong position
        else:
            feedback.append("⬜")  # Letter not in the target word
    return ''.join(feedback)

# Start the game
print("Welcome to Wordle!")
print("You have 6 attempts to guess the 5-letter word.")

attempts = 6
while attempts > 0:
    guess = input(f"\nEnter your guess ({attempts} attempts left): ").lower()

    if len(guess) != 5:
        print("Please enter a 5-letter word.")
        continue

    if guess not in word_list:
        print("Invalid word. Please try again.")
        continue

    feedback = get_feedback(guess, target_word)
    print("Feedback:", feedback)

    if guess == target_word:
        print("🎉 Congratulations! You guessed the word!")
        break

    attempts -= 1

if attempts == 0:
    print(f"\nGame over! The word was: {target_word}")